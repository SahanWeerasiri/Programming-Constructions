package Mystic_Mayhem;

import Mystic_Mayhem.Characters.GameCharacter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

public class Player {

    private final User user;
    private float[] character_healths = new float[5];
    private float[] character_attack = new float[5];
    private float[] character_defense = new float[5];
    private float[] character_speed = new float[5];
    private final String location;

    private List<GameCharacter> attackers_in_speed_order;
    private List<GameCharacter> defenders_in_defense_order;
    private List<String> dead;

    private int turn = 1;

    public int getTurn() {
        return turn;
    }

    public void setTurn(int turn) {
        this.turn = turn;
    }

    private GameCharacter cuurent_attacker, current_defender;

    public Player(User user, String location) {
        this.location = location;
        this.user = user;

        //Save health data to restore later
        saveData();

        attackers_in_speed_order = new ArrayList<>();
        defenders_in_defense_order = new ArrayList<>();
        dead = new ArrayList<>();

        updateStatesOfCharactersInHomeGrounds();
        readyArmyInHighSpeedOrder();
        readyArmyInLowDefenseOrder();

        cuurent_attacker = attackers_in_speed_order.get(0);
        current_defender = defenders_in_defense_order.get(0);

    }

    private void saveData() {
        GameCharacter[] gc = {user.getArmy().getArcher(), user.getArmy().getKnight(), user.getArmy().getMage(), user.getArmy().getHealer(), user.getArmy().getMythicalCreature()};
        for (int i = 0; i < 5; i++) {
            character_healths[i] = gc[i].getHealth();
            character_speed[i] = gc[i].getSpeed();
            character_attack[i] = gc[i].getAttack();
            character_defense[i] = gc[i].getDefense();
        }
    }

    private void updateStatesOfCharactersInHomeGrounds() {
        user.getArmy().getArcher().changeCharacterProperties(location);
        user.getArmy().getKnight().changeCharacterProperties(location);
        user.getArmy().getMage().changeCharacterProperties(location);
        user.getArmy().getHealer().changeCharacterProperties(location);
        user.getArmy().getMythicalCreature().changeCharacterProperties(location);
    }

    private void readyArmyInHighSpeedOrder() {
        boolean is_finished = false;
        List<Float> temp = new ArrayList<>();
        temp.add(user.getArmy().getArcher().getSpeed());
        temp.add(user.getArmy().getKnight().getSpeed());
        temp.add(user.getArmy().getMythicalCreature().getSpeed());
        temp.add(user.getArmy().getMage().getSpeed());
        temp.add(user.getArmy().getHealer().getSpeed());
        while (!is_finished) {
            //find maximum speed character
            int max = 0;
            for (int i = 1; i < temp.size(); i++) {
                if (temp.get(max) < temp.get(i)) {
                    max = i;
                }
            }
            switch (max) {
                case 0:
                    attackers_in_speed_order.add(user.getArmy().getArcher());
                    break;
                case 1:
                    attackers_in_speed_order.add(user.getArmy().getKnight());
                    break;
                case 2:
                    attackers_in_speed_order.add(user.getArmy().getMythicalCreature());
                    break;
                case 3:
                    attackers_in_speed_order.add(user.getArmy().getMage());
                    break;
                case 4:
                    attackers_in_speed_order.add(user.getArmy().getHealer());
                    break;
                default:
                    break;
            }

            //avoid interfer from used characters
            temp.set(max, Float.MIN_VALUE);
            if (attackers_in_speed_order.size() == temp.size()) {
                is_finished = true;
            }
        }
    }

    private void readyArmyInLowDefenseOrder() {
        boolean is_finished = false;
        List<Float> temp = new ArrayList<>();
        temp.add(user.getArmy().getMage().getDefense());
        temp.add(user.getArmy().getKnight().getDefense());
        temp.add(user.getArmy().getArcher().getDefense());
        temp.add(user.getArmy().getMythicalCreature().getDefense());
        temp.add(user.getArmy().getHealer().getDefense());
        while (!is_finished) {
            int min = 0;
            for (int i = 1; i < temp.size(); i++) {
                if (temp.get(min) > temp.get(i)) {
                    min = i;
                }
            }
            switch (min) {
                case 0:
                    defenders_in_defense_order.add(user.getArmy().getMage());
                    break;
                case 1:
                    defenders_in_defense_order.add(user.getArmy().getKnight());
                    break;
                case 2:
                    defenders_in_defense_order.add(user.getArmy().getArcher());
                    break;
                case 3:
                    defenders_in_defense_order.add(user.getArmy().getMythicalCreature());
                    break;
                case 4:
                    defenders_in_defense_order.add(user.getArmy().getHealer());
                    break;
                default:
                    break;
            }
            //avoid interfer from used characters
            temp.set(min, Float.MAX_VALUE);
            if (defenders_in_defense_order.size() == temp.size()) {
                is_finished = true;
            }
        }
    }

    public GameCharacter getCuurent_attacker(boolean is_turn) {
        if (attackers_in_speed_order.isEmpty()) {
            cuurent_attacker = null;
        } else {
            if (is_turn) {
                GameCharacter temp = attackers_in_speed_order.get(0);
                attackers_in_speed_order.remove(0);
                attackers_in_speed_order.add(temp);

            }
            cuurent_attacker = attackers_in_speed_order.get(0);
        }
        return cuurent_attacker;
    }

    public GameCharacter getCuurent_defender() {
        if (defenders_in_defense_order.isEmpty()) {
            current_defender = null;
        } else {
            current_defender = defenders_in_defense_order.get(0);
        }
        return current_defender;
    }

    public GameCharacter getLowHealthedCharacter() {
        HashMap<String, Float> temp = new HashMap<>();
        temp.put(user.getArmy().getArcher().getName(), user.getArmy().getArcher().getHealth());
        temp.put(user.getArmy().getKnight().getName(), user.getArmy().getKnight().getHealth());
        temp.put(user.getArmy().getMage().getName(), user.getArmy().getMage().getHealth());
        temp.put(user.getArmy().getHealer().getName(), user.getArmy().getHealer().getHealth());
        temp.put(user.getArmy().getMythicalCreature().getName(), user.getArmy().getMythicalCreature().getHealth());
        for (String die : dead) {
            temp.put(die, Float.MAX_VALUE);
        }
        Set<String> names = temp.keySet();
        String min = "";
        for (String name : names) {
            if (min.equals("")) {
                min = name;
                continue;
            }
            if (temp.get(name) < temp.get(min)) {
                min = name;
            }
        }
        if (min.equals(user.getArmy().getArcher().getName())) {
            return user.getArmy().getArcher();
        } else if (min.equals(user.getArmy().getKnight().getName())) {
            return user.getArmy().getKnight();
        } else if (min.equals(user.getArmy().getMage().getName())) {
            return user.getArmy().getMage();
        } else if (min.equals(user.getArmy().getHealer().getName())) {
            return user.getArmy().getHealer();
        } else if (min.equals(user.getArmy().getMythicalCreature().getName())) {
            return user.getArmy().getMythicalCreature();
        } else {
            return null;
        }
    }

    public float getBonusAttack() {
        return cuurent_attacker.getBonusTurnIncrement(location);
    }

    public float getBonusHealth() {
        return cuurent_attacker.getIncrementOHealth(location);
    }

    public void attack(boolean is_bonus) {
        GameCharacter gc = getLowHealthedCharacter();
        if (is_bonus) {
            if (cuurent_attacker.isAHealer() && gc != null) {
                System.out.println("\u001B[5m" + "Bonus Turn" + "\u001B[0m");
                gc.setHealth((float) (getLowHealthedCharacter().getHealth() + 0.1 * cuurent_attacker.getAttack() * 0.2));
                System.out.printf("\u001B[32m" + "%s heals %s \tHealth: %.1f" + "\u001B[0m" + "\n", cuurent_attacker.getName(), gc.getName(), gc.getHealth());
            }
        } else {
            if (cuurent_attacker.isAHealer() && gc != null) {
                gc.setHealth((float) (getLowHealthedCharacter().getHealth() + 0.1 * cuurent_attacker.getAttack()));
                System.out.printf("\u001B[32m" + "%s heals %s \tHealth: %.1f" + "\u001B[0m" + "\n", cuurent_attacker.getName(), gc.getName(), gc.getHealth());
            }
        }

    }

    private void dieCharacter(GameCharacter gc) {
        defenders_in_defense_order.remove(0);

        int index = 0;
        for (GameCharacter g : attackers_in_speed_order) {
            if (gc.getName().contains(g.getName())) {
                break;
            }
            index++;
        }
        attackers_in_speed_order.remove(index);

    }

    public void attackedByOther(Player oppo, boolean is_bonus) {
        if (is_bonus) {
            //avoid healer's attack
            if (!oppo.getCuurent_attacker(false).isAHealer()) {
                current_defender.setHealth((float) (current_defender.getHealth() - (0.5 * (oppo.getCuurent_attacker(false).getAttack() * 0.2) - 0.1 * (current_defender.getDefense()))));
                System.out.println("\u001B[5m" + "Bonus Turn for " + oppo.getUser().getUser_name() + "\u001B[0m");
                System.out.println(oppo.getCuurent_attacker(false).getName() + " attacks " + getCuurent_defender().getName());
                System.out.printf("%s's health: %.1f\n", getCuurent_defender().getName(), getCuurent_defender().getHealth());
                System.out.printf("%s's health: %.1f\n", oppo.getCuurent_attacker(false).getName(), oppo.getCuurent_attacker(false).getHealth());
            }
        } else {
            //avoid healer's attack
            if (!oppo.getCuurent_attacker(false).isAHealer()) {
                current_defender.setHealth((float) (current_defender.getHealth() - (0.5 * (oppo.getCuurent_attacker(false).getAttack()) - 0.1 * (current_defender.getDefense()))));
                System.out.println(oppo.getCuurent_attacker(false).getName() + " attacks " + getCuurent_defender().getName());
                System.out.printf("%s's health: %.1f\n", getCuurent_defender().getName(), getCuurent_defender().getHealth());
                System.out.printf("%s's health: %.1f\n", oppo.getCuurent_attacker(false).getName(), oppo.getCuurent_attacker(false).getHealth());
            }
        }

        if (current_defender.getHealth() <= 0) {
            dead.add(current_defender.getName());
            System.out.println("\u001B[31m" + current_defender.getName() + " died!" + "\u001B[0m");
            dieCharacter(current_defender);
            current_defender = getCuurent_defender();
        }
        System.out.println("......................................................");
    }

    public void restore() {
        GameCharacter[] gc = {user.getArmy().getArcher(), user.getArmy().getKnight(), user.getArmy().getMage(), user.getArmy().getHealer(), user.getArmy().getMythicalCreature()};
        for (int i = 0; i < 5; i++) {
            gc[i].setHealth(character_healths[i]);
            gc[i].setAttack(character_attack[i]);
            gc[i].setSpeed(character_speed[i]);
            gc[i].setDefense(character_defense[i]);
        }
    }

    public User getUser() {
        return user;
    }

    public List<String> getDead() {
        return dead;
    }

    public float[] getCharacter_healths() {
        return character_healths;
    }
}
