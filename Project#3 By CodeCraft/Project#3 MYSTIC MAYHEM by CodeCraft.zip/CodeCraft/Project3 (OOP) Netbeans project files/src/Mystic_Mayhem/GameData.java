package Mystic_Mayhem;

import Mystic_Mayhem.Characters.Archer;
import Mystic_Mayhem.Characters.GameCharacter;
import Mystic_Mayhem.Characters.Healer;
import Mystic_Mayhem.Characters.Knight;
import Mystic_Mayhem.Characters.Mage;
import Mystic_Mayhem.Characters.MythicalCreature;
import Mystic_Mayhem.Equipments.Armour;
import Mystic_Mayhem.Equipments.Artefact;
import Mystic_Mayhem.Equipments.Equipment;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class GameData {

    //Game variables
    private static HashMap<Integer, User> USERS = new HashMap<>();
    private static HashMap<String, HashMap> CHARACTERS = new HashMap<>();
    private static HashMap<String, HashMap> EQUIPMENTS = new HashMap<>();
    private static final List<String> USER_NAMES = new ArrayList<>();
    private static final List<Integer> USER_IDS = new ArrayList<>();

    private static final String GAME_NAME = "\n\n\n"+"\u001B[5m" + "███╗   ███╗██╗   ██╗███████╗████████╗██╗ ██████╗               " + "\u001B[0m" + "\n"
            + "\u001B[5m" + "████╗ ████║╚██╗ ██╔╝██╔════╝╚══██╔══╝██║██╔════╝               " + "\u001B[0m" + "\n"
            + "\u001B[5m" + "██╔████╔██║ ╚████╔╝ ███████╗   ██║   ██║██║                    " + "\u001B[0m" + "\n"
            + "\u001B[5m" + "██║╚██╔╝██║  ╚██╔╝  ╚════██║   ██║   ██║██║                    " + "\u001B[0m" + "\n"
            + "\u001B[5m" + "██║ ╚═╝ ██║   ██║   ███████║   ██║   ██║╚██████╗               " + "\u001B[0m" + "\n"
            + "\u001B[5m" + "╚═╝     ╚═╝   ╚═╝   ╚══════╝   ╚═╝   ╚═╝ ╚═════╝               " + "\u001B[0m" + "\n"
            + "\u001B[5m" + "                                                              " + "\u001B[0m" + "\n"
            + "\u001B[5m" + "        ███╗   ███╗ █████╗ ██╗   ██╗██╗  ██╗███████╗███╗   ███╗" + "\u001B[0m" + "\n"
            + "\u001B[5m" + "        ████╗ ████║██╔══██╗╚██╗ ██╔╝██║  ██║██╔════╝████╗ ████║" + "\u001B[0m" + "\n"
            + "\u001B[5m" + "        ██╔████╔██║███████║ ╚████╔╝ ███████║█████╗  ██╔████╔██║" + "\u001B[0m" + "\n"
            + "\u001B[5m" + "        ██║╚██╔╝██║██╔══██║  ╚██╔╝  ██╔══██║██╔══╝  ██║╚██╔╝██║" + "\u001B[0m" + "\n"
            + "\u001B[5m" + "        ██║ ╚═╝ ██║██║  ██║   ██║   ██║  ██║███████╗██║ ╚═╝ ██║" + "\u001B[0m" + "\n"
            + "\u001B[5m" + "        ╚═╝     ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═╝╚══════╝╚═╝     ╚═╝" + "\u001B[0m" + "\n"
            + "                                                               \n";
    private static final String FRAME = "                                                                        \n"
            + "                                                                        \n"
            + "█████╗█████╗█████╗█████╗█████╗█████╗\n"
            + "╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝\n"
            + "                                                                        \n";

    public static String getFRAME() {
        return FRAME;
    }

    public static String getGAME_NAME() {
        return GAME_NAME;
    }

    private static final String DEFAULT_PLAYER = "whitewolf";

    public static String getDEFAULT_PLAYER() {
        return DEFAULT_PLAYER;
    }
    
    private static final String ARCHER = "Archer";
    private static final String KNIGHT = "Knight";
    private static final String MAGE = "Mage";
    private static final String HEALER = "Healer";
    private static final String MYTHICAL_CREATURE = "MythicalCreature";

    private static final String ARMOUR = "Armour";
    private static final String ARTEFACT = "Artefact";

    private static final String ARCHER_NAMES[] = {"Shooter", "Ranger", "Sunfire", "Zing", "Saggitarius"};
    private static final String KNIGHT_NAMES[] = {"Squire", "Cavalier", "Templar", "Zoro", "Swiftblade"};
    private static final String MAGE_NAMES[] = {"Warlock", "Illusionist", "Enchanter", "Conjurer", "Eldritch"};
    private static final String HEALER_NAMES[] = {"Soother", "Medic", "Alchemist", "Saint", "Lightbringer"};
    private static final String MYTHICAL_CREATURE_NAMES[] = {"Dragon", "Basilisk", "Hydra", "Phoenix", "Pegasus"};

    private static final String ARMOUR_NAMES[] = {"Chainmail", "Regalia", "Fleece"};
    private static final String ARTEFACT_NAMES[] = {"Excalibur", "Amulet", "Crystal"};

    private static final String ALL_CHARACTER_NAMES[][] = {{getARCHER(), "Shooter", "Ranger", "Sunfire", "Zing", "Saggitarius"}, {getKNIGHT(), "Squire", "Cavalier", "Templar", "Zoro", "Swiftblade"},
    {getMAGE(), "Warlock", "Illusionist", "Enchanter", "Conjurer", "Eldritch"}, {getHEALER(), "Soother", "Medic", "Alchemist", "Saint", "Lightbringer"},
    {getMYTHICAL_CREATURE(), "Dragon", "Basilisk", "Hydra", "Phoenix", "Pegasus"}};

    private static final String[][] ALL_EQUIPMENT_NAMES = {{getARMOUR(), "Chainmail", "Regalia", "Fleece"}, {getARTEFACT(), "Excalibur", "Amulet", "Crystal"}};

    private static final String HILLCREST = "Hillcrest";
    private static final String MARSHALAND = "Marshland";
    private static final String DESERT = "Desert";
    private static final String ARCANE = "Arcane";

    private static final String[] HOME_GROUNDS = {"Hillcrest", "Marshland", "Desert", "Arcane"};

    private static final String ARMY = "Army";
    private static final String EQUIPMENT = "Equipment";
    private static final String BACK = "BACK";

    private static final String HIGHLANDERS = "Highlanders";
    private static final String MARSHALANDERS = "Marshlanders";
    private static final String SUNCHILDREN = "Sunchildren";
    private static final String MYSTICS = "Mystics";

    public static void loadGameData() {
        try {
            FileInputStream fis = new FileInputStream("Data.ser");
            BufferedInputStream bis = new BufferedInputStream(fis);
            ObjectInputStream ois = new ObjectInputStream(bis);
            Object obj;
            while (bis.available() > 0) {
                obj = ois.readObject();
                User user = (User) obj;
                USERS.put(user.getUser_ID(), user);
                USER_NAMES.add(user.getUser_name());
                USER_IDS.add(user.getUser_ID());
            }
            User.setUserCount(USERS.size());
            ois.close();
            fis.close();
            System.out.println("Saved Data are loaded!");

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error in loading data. Restart the game" + e.toString());
        }

    }

    public static void createHackers() {
        User default_user = new User("ABCD", "Batman", getMARSHALAND());
        default_user.setXP(32);
        default_user.setGold_coins(4000);
        Army army = new Army();
        HashMap<String, HashMap<String, GameCharacter>> clone_map = (HashMap<String, HashMap<String, GameCharacter>>) getCHARACTERS().clone();
        HashMap<String, HashMap<String, Equipment>> clone_eqip = (HashMap<String, HashMap<String, Equipment>>) getEQUIPMENTS().clone();
        army.setArcher((Archer) clone_map.get(getARCHER()).get(getARCHER_NAMES()[1]));
        army.setKnight((Knight) clone_map.get(getKNIGHT()).get(getKNIGHT_NAMES()[3]));
        army.setMage((Mage) clone_map.get(getMAGE()).get(getMAGE_NAMES()[2]));
        army.setHealer((Healer) clone_map.get(getHEALER()).get(getHEALER_NAMES()[0]));
        army.setMythicalCreature((MythicalCreature) clone_map.get(getMYTHICAL_CREATURE()).get(getMYTHICAL_CREATURE_NAMES()[0]));
        default_user.setArmy(army);
        addUsers(default_user);
    }

    public static void createDefaultUser() {

        User default_user = new User("GeraltofRivia", "whitewolf", getMARSHALAND());
        default_user.setXP(32);
        default_user.setGold_coins(215);
        Army army = new Army();
        HashMap<String, HashMap<String, GameCharacter>> clone_map = (HashMap<String, HashMap<String, GameCharacter>>) getCHARACTERS().clone();
        HashMap<String, HashMap<String, Equipment>> clone_eqip = (HashMap<String, HashMap<String, Equipment>>) getEQUIPMENTS().clone();
        army.setArcher((Archer) clone_map.get(getARCHER()).get(getARCHER_NAMES()[1]));
        army.setKnight((Knight) clone_map.get(getKNIGHT()).get(getKNIGHT_NAMES()[0]));
        army.setMage((Mage) clone_map.get(getMAGE()).get(getMAGE_NAMES()[0]));
        army.setHealer((Healer) clone_map.get(getHEALER()).get(getHEALER_NAMES()[1]));
        army.setMythicalCreature((MythicalCreature) clone_map.get(getMYTHICAL_CREATURE()).get(getMYTHICAL_CREATURE_NAMES()[0]));
        army.getArcher().setArmour((Armour) clone_eqip.get(getARMOUR()).get(getARMOUR_NAMES()[0]));
        army.getHealer().setArtefact((Artefact) clone_eqip.get(getARTEFACT()).get(getARTEFACT_NAMES()[1]));
        default_user.setArmy(army);
        default_user.putEquipment(army.getArcher(), army.getArcher().getArmour());
        default_user.putEquipment(army.getHealer(), army.getHealer().getArtefact());
        addUsers(default_user);

        //My use
        default_user = new User("Sahan", "Dark", getARCANE());
        default_user.setXP(32);
        default_user.setGold_coins(215);
        army = new Army();
        army.setArcher((Archer) clone_map.get(getARCHER()).get(getARCHER_NAMES()[4]));
        army.setKnight((Knight) clone_map.get(getKNIGHT()).get(getKNIGHT_NAMES()[4]));
        army.setMage((Mage) clone_map.get(getMAGE()).get(getMAGE_NAMES()[4]));
        army.setHealer((Healer) clone_map.get(getHEALER()).get(getHEALER_NAMES()[4]));
        army.setMythicalCreature((MythicalCreature) clone_map.get(getMYTHICAL_CREATURE()).get(getMYTHICAL_CREATURE_NAMES()[4]));
        default_user.setArmy(army);
        addUsers(default_user);

        //My use
        createHackers();

    }

    public static void createCharactersAndEquipments() {
        HashMap<String, GameCharacter> temp_Characters = new HashMap<>();
        HashMap<String, Equipment> temp_equipment = new HashMap<>();

        //name,speed, price, attack, defense, health,Category
        temp_Characters.put("Shooter", new Archer("Shooter", 9, 80, 11, 4, 6, getHIGHLANDERS()).getInstance());
        temp_Characters.put("Ranger", new Archer("Ranger", 10, 115, 14, 5, 8, getHIGHLANDERS()).getInstance());
        temp_Characters.put("Sunfire", new Archer("Sunfire", 14, 160, 15, 5, 7, getSUNCHILDREN()).getInstance());
        temp_Characters.put("Zing", new Archer("Zing", 14, 200, 16, 9, 11, getSUNCHILDREN()).getInstance());
        temp_Characters.put("Saggitarius", new Archer("Saggitarius", 17, 230, 18, 7, 12, getMYSTICS()).getInstance());

        CHARACTERS.put("Archer", (HashMap) temp_Characters.clone());
        temp_Characters.clear();

        temp_Characters.put("Squire", new Knight("Squire", 8, 85, 8, 9, 7, getMARSHALANDERS()).getInstance());
        temp_Characters.put("Cavalier", new Knight("Cavalier", 10, 110, 10, 12, 7, getHIGHLANDERS()).getInstance());
        temp_Characters.put("Templar", new Knight("Templar", 12, 155, 14, 16, 12, getSUNCHILDREN()).getInstance());
        temp_Characters.put("Zoro", new Knight("Zoro", 14, 180, 17, 16, 13, getHIGHLANDERS()).getInstance());
        temp_Characters.put("Swiftblade", new Knight("Swiftblade", 13, 250, 18, 20, 17, getMARSHALANDERS()).getInstance());

        CHARACTERS.put("Knight", (HashMap) temp_Characters.clone());
        temp_Characters.clear();

        temp_Characters.put("Warlock", new Mage("Warlock", 12, 100, 12, 7, 10, getMARSHALANDERS()).getInstance());
        temp_Characters.put("Illusionist", new Mage("Illusionist", 14, 120, 13, 8, 12, getMYSTICS()).getInstance());
        temp_Characters.put("Enchanter", new Mage("Enchanter", 16, 160, 16, 10, 13, getHIGHLANDERS()).getInstance());
        temp_Characters.put("Conjurer", new Mage("Conjurer", 12, 195, 18, 15, 14, getHIGHLANDERS()).getInstance());
        temp_Characters.put("Eldritch", new Mage("Eldritch", 14, 270, 19, 17, 18, getMYSTICS()).getInstance());

        CHARACTERS.put("Mage", (HashMap) temp_Characters.clone());
        temp_Characters.clear();

        temp_Characters.put("Soother", new Healer("Soother", 6, 95, 10, 8, 9, getSUNCHILDREN()).getInstance());
        temp_Characters.put("Medic", new Healer("Medic", 7, 125, 12, 9, 10, getHIGHLANDERS()).getInstance());
        temp_Characters.put("Alchemist", new Healer("Alchemist", 13, 150, 13, 13, 13, getMARSHALANDERS()).getInstance());
        temp_Characters.put("Saint", new Healer("Saint", 9, 200, 16, 14, 17, getMYSTICS()).getInstance());
        temp_Characters.put("Lightbringer", new Healer("Lightbringer", 12, 260, 17, 15, 19, getSUNCHILDREN()).getInstance());

        CHARACTERS.put("Healer", (HashMap) temp_Characters.clone());
        temp_Characters.clear();

        temp_Characters.put("Dragon", new MythicalCreature("Dragon", 8, 120, 12, 14, 15, getSUNCHILDREN()).getInstance());
        temp_Characters.put("Basilisk", new MythicalCreature("Basilisk", 12, 165, 15, 11, 10, getMARSHALANDERS()).getInstance());
        temp_Characters.put("Hydra", new MythicalCreature("Hydra", 11, 205, 12, 16, 15, getMARSHALANDERS()).getInstance());
        temp_Characters.put("Phoenix", new MythicalCreature("Phoenix", 19, 275, 17, 13, 17, getSUNCHILDREN()).getInstance());
        temp_Characters.put("Pegasus", new MythicalCreature("Pegasus", 20, 340, 14, 18, 20, getMYSTICS()).getInstance());

        CHARACTERS.put("MythicalCreature", (HashMap) temp_Characters.clone());
        temp_Characters.clear();

        temp_equipment.put("Chainmail", new Armour("Chainmail", -1, 70, 0, 1, 0));
        temp_equipment.put("Regalia", new Armour("Regalia", 0, 105, 0, 1, 0));
        temp_equipment.put("Fleece", new Armour("Fleece", -1, 150, 0, 2, 1));

        EQUIPMENTS.put("Armour", (HashMap) temp_equipment.clone());
        temp_equipment.clear();

        temp_equipment.put("Excalibur", new Artefact("Excalibur", 0, 150, 2, 0, 0));
        temp_equipment.put("Amulet", new Artefact("Amulet", 1, 200, 1, -1, 1));
        temp_equipment.put("Crystal", new Artefact("Crystal", -1, 210, 2, 1, -1));

        EQUIPMENTS.put("Artefact", (HashMap) temp_equipment.clone());
        temp_equipment.clear();

        System.out.println("Characters are created!");
    }

    public static void addUsers(User user) {
        USERS.put(user.getUser_ID(), user);
        USER_NAMES.add(user.getUser_name());
        USER_IDS.add(user.getUser_ID());
    }

    public static void deleteUsers(int user_id) {
        USERS.remove(user_id);
    }

    public static void saveGameData() {
        try {
            FileOutputStream fos = new FileOutputStream("Data.ser");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            Set<Integer> keys = USERS.keySet();
            Iterator<Integer> iterator = keys.iterator();
            while (iterator.hasNext()) {
                oos.writeObject(USERS.get(iterator.next()));
            }
            oos.close();
            fos.close();
            System.out.println("\u001B[32m" + "Saved!" + "\u001B[0m");
        } catch (IOException e) {
            System.err.println("\u001B[31m" + "Error in saving data. Restart the game" + "\u001B[0m");
        }
    }

    public static String getHILLCREST() {
        return HILLCREST;
    }

    public static String getMARSHALAND() {
        return MARSHALAND;
    }

    public static String getDESERT() {
        return DESERT;
    }

    public static String getARCANE() {
        return ARCANE;
    }

    public static String[] getHOME_GROUNDS() {
        return HOME_GROUNDS;
    }

    public static String getHIGHLANDERS() {
        return HIGHLANDERS;
    }

    public static String getMARSHALANDERS() {
        return MARSHALANDERS;
    }

    public static String getSUNCHILDREN() {
        return SUNCHILDREN;
    }

    public static String getMYSTICS() {
        return MYSTICS;
    }

    public static String getBACK() {
        return BACK;
    }

    public static String[][] getALL_CHARACTER_NAMES() {
        return ALL_CHARACTER_NAMES;
    }

    public static String[][] getALL_EQUIPMENT_NAMES() {
        return ALL_EQUIPMENT_NAMES;
    }

    public static HashMap<Integer, User> getUsers() {
        return USERS;
    }

    public static List<String> getUSER_NAMES() {
        return USER_NAMES;
    }

    public static List<Integer> getUSER_IDS() {
        return USER_IDS;
    }

    public static HashMap<String, HashMap> getCHARACTERS() {
        return CHARACTERS;
    }

    public static HashMap<String, HashMap> getEQUIPMENTS() {
        return EQUIPMENTS;
    }

    public static String getARCHER() {
        return ARCHER;
    }

    public static String getKNIGHT() {
        return KNIGHT;
    }

    public static String getMAGE() {
        return MAGE;
    }

    public static String getHEALER() {
        return HEALER;
    }

    public static String getMYTHICAL_CREATURE() {
        return MYTHICAL_CREATURE;
    }

    public static String getARMOUR() {
        return ARMOUR;
    }

    public static String getARTEFACT() {
        return ARTEFACT;
    }

    public static String[] getARCHER_NAMES() {
        return ARCHER_NAMES;
    }

    public static String[] getKNIGHT_NAMES() {
        return KNIGHT_NAMES;
    }

    public static String[] getMAGE_NAMES() {
        return MAGE_NAMES;
    }

    public static String[] getHEALER_NAMES() {
        return HEALER_NAMES;
    }

    public static String[] getMYTHICAL_CREATURE_NAMES() {
        return MYTHICAL_CREATURE_NAMES;
    }

    public static String[] getARMOUR_NAMES() {
        return ARMOUR_NAMES;
    }

    public static String[] getARTEFACT_NAMES() {
        return ARTEFACT_NAMES;
    }

    public static String getARMY() {
        return ARMY;
    }

    public static String getEQUIPMENT() {
        return EQUIPMENT;
    }
}
