package Mystic_Mayhem;

import Mystic_Mayhem.Characters.GameCharacter;
import Mystic_Mayhem.Equipments.Armour;
import Mystic_Mayhem.Equipments.Artefact;
import Mystic_Mayhem.Equipments.Equipment;
import Mystic_Mayhem.Menus.ConfirmMenu;
import java.io.Serializable;
import java.util.Scanner;

public class User implements Serializable {

    private static int USER_COUNT = 0;
    private String user_name, name;
    private int gold_coins, XP, user_id;
    private Army army = new Army();
    private User USER = this;
    private String home_ground;

    public User(String name, String user_name, String homeground) {
        this.name = name;
        this.user_name = user_name;
        this.XP = 1;
        this.gold_coins = 500;
        this.user_id = this.createUserID();
        this.home_ground = homeground;
    }

    public String getHome_ground() {
        return home_ground;
    }

    public String getUser_name() {
        return user_name;
    }

    public int getUser_ID() {
        return user_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getGold_coins() {
        return gold_coins;
    }

    public void setGold_coins(int gold_coins) {
        if (gold_coins < 0) {
            this.gold_coins = 0;
        } else {
            this.gold_coins = gold_coins;
        }
    }

    public int getXP() {
        return XP;
    }

    public void setXP(int XP) {
        this.XP = XP;
    }

    public Army getArmy() {
        return army;
    }

    public void setArmy(Army army) {
        this.army = army;
    }

    private int createUserID() {
        USER_COUNT++;
        return USER_COUNT;
    }

    public static void setUserCount(int count) {
        USER_COUNT = count;
    }
    
    public String getUserArmyDetails(){
        String msg="Army :\n";
        if(getArmy().getArcher()!=null)
            msg+=GameData.getARCHER()+": "+getArmy().getArcher().getName()+",\t";
        if(getArmy().getKnight()!=null)
            msg+=GameData.getKNIGHT()+": "+getArmy().getKnight().getName()+",\t";
        if(getArmy().getMage()!=null)
            msg+=GameData.getMAGE()+": "+getArmy().getMage().getName()+",\t";
        if(getArmy().getHealer()!=null)
            msg+=GameData.getHEALER()+": "+getArmy().getHealer().getName()+",\t";
        if(getArmy().getMythicalCreature()!=null)
            msg+=GameData.getMYTHICAL_CREATURE()+": "+getArmy().getMythicalCreature().getName()+"\n";
        if(msg.equals("Army :\n"))
            return msg+"None";
        return msg;
    }

    public void printProfile() {
        String msg = "User name  : " + this.user_name
                + "\nUser ID    : " + this.user_id
                + "\nName       : " + this.name
                + "\nGold coins : " + this.gold_coins
                + "\nXP         : " + this.XP
                + "\nHome Ground: " + this.home_ground + "\n";
        msg += addCharacterData(army.getArcher(), GameData.getARCHER());
        msg += addCharacterData(army.getKnight(), GameData.getKNIGHT());
        msg += addCharacterData(army.getMage(), GameData.getMAGE());
        msg += addCharacterData(army.getHealer(), GameData.getHEALER());
        msg += addCharacterData(army.getMythicalCreature(), GameData.getMYTHICAL_CREATURE());

        System.out.println(msg);
    }

    private String addCharacterData(GameCharacter gc, String name) {
        if (gc != null) {
            String msg = String.format("%20s", name)+  "\t" +String.format("%15s", gc.getName())+  "\t\tSpeed: " + gc.getSpeed() + "\tPrice: " + gc.getPrice() + " gc\tAttack: " + gc.getAttack() + "\tDefense: " + gc.getDefense() + "\tHealth: " + gc.getHealth() + "\tOrigin: " + gc.getCategory();
            Armour armour = gc.getArmour();
            Artefact artefact = gc.getArtefact();
            if (armour != null) {
                msg += "\n\tArmour :" + String.format("%15s", armour.getName()) + "\t\tSpeed: " + armour.getSpeed() + "\tPrice: " + armour.getPrice() + " gc\tAttack: " + armour.getAttack() + "\tDefense: " + armour.getDefense() + "\tHealth: " + armour.getHealth() + "\n";
            }
            if (artefact != null) {
                msg += "\n\tArtefact :" + String.format("%15s", artefact.getName()) + "\t\tSpeed: " + artefact.getSpeed() + "\tPrice: " + artefact.getPrice() + " gc\tAttack: " + artefact.getAttack() + "\tDefense: " + artefact.getDefense() + "\tHealth: " + artefact.getHealth() + "\n";
            }
            return msg + "\n";
        }
        return name + ": null\n";
    }

    public void changeName() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter your new name :\t");
        String nam = scanner.nextLine();
        setName(nam);
        System.out.println("\u001B[32m" + "Name has changed." + "\u001B[0m");
    }

    public boolean shouldUserBuy(GameCharacter gc, int total, String type) {
        int least_archer = 80, least_knight = 85, least_mage = 100, least_healer = 95, least_mythical = 120;
        
        if (getArmy().getArcher() == null && !type.equals(GameData.getARCHER())) {
            total -= least_archer;
        }
        if (getArmy().getKnight() == null && !type.equals(GameData.getKNIGHT())) {
            total -= least_knight;
        }
        if (getArmy().getMage() == null && !type.equals(GameData.getMAGE())) {
            total -= least_mage;
        }
        if (getArmy().getHealer() == null && !type.equals(GameData.getHEALER())) {
            total -= least_healer;
        }
        if (getArmy().getMythicalCreature() == null && !type.equals(GameData.getMYTHICAL_CREATURE())) {
            total -= least_mythical;
        }
        total-=gc.getPrice();
        return (total>=0);
    }

    private boolean checkForExistingCharacters(GameCharacter gc) {
        if (getArmy().getArcher() != null) {
            if (gc.getName().equals(getArmy().getArcher().getName())) {
                return true;
            }
        }
        if (getArmy().getKnight() != null) {
            if (gc.getName().equals(getArmy().getKnight().getName())) {
                return true;
            }
        }
        if (getArmy().getMage() != null) {
            if (gc.getName().equals(getArmy().getMage().getName())) {
                return true;
            }
        }
        if (getArmy().getHealer() != null) {
            if (gc.getName().equals(getArmy().getHealer().getName())) {
                return true;
            }
        }
        if (getArmy().getMythicalCreature() != null) {
            if (gc.getName().equals(getArmy().getMythicalCreature().getName())) {
                return true;
            }
        }
        return false;
    }

    private boolean checkForExistingEquipment(Equipment equip, GameCharacter gc, String type) {
        return equip.getName().equals(gc.getEquipment(type).getName());
    }

    public void removeEquipment(GameCharacter gc, String type) {
        gc.setPrice((int) (gc.getPrice() - gc.getEquipment(type).getPrice() * 0.2));
        gc.setAttack((gc.getAttack() - gc.getEquipment(type).getAttack()));
        gc.setDefense((gc.getDefense() - gc.getEquipment(type).getDefense()));
        gc.setHealth((gc.getHealth() - gc.getEquipment(type).getHealth()));
        gc.setSpeed((gc.getSpeed() - gc.getEquipment(type).getSpeed()));

    }

    public void putEquipment(GameCharacter gc, Equipment equipment) {
        gc.setPrice((int) (gc.getPrice() + (Math.round(equipment.getPrice() * 0.2))));
        gc.setSpeed(gc.getSpeed() + equipment.getSpeed());
        gc.setDefense(gc.getDefense() + equipment.getDefense());
        gc.setAttack(gc.getAttack() + equipment.getAttack());
        gc.setHealth(gc.getHealth() + equipment.getHealth());

    }

    public void buyEquipment(Equipment buying_equipment, String character, String type_name) {
        GameCharacter gc = getArmy().getCharacter(character);
        ConfirmMenu cm = new ConfirmMenu();
        if (cm.getResponse()) {
            if (gc == null) {
                System.out.println("\u001B[31m" + "You haven't this character. Try another character" + "\u001B[0m" + "\n");
                return;
            }
            if (getGold_coins() >= buying_equipment.getPrice() && getArmy().getCharacterByName(gc.getName()).getEquipment(type_name) == null) {
                setGold_coins(getGold_coins() - buying_equipment.getPrice());
                gc.setEquipment(buying_equipment, type_name);
                putEquipment(gc, buying_equipment);
                System.out.println("\u001B[32m" +buying_equipment.getName()+ " is added to "+gc.getName()+ " ("+character+")" + "\u001B[0m" + "\n");
            } else if (getGold_coins() >= buying_equipment.getPrice() && getArmy().getCharacterByName(gc.getName()).getEquipment(type_name) != null) {
                if (checkForExistingEquipment(buying_equipment, gc, type_name)) {
                    System.out.println("\u001B[31m" + "You already have this equipment with this character" + "\u001B[0m" + "\n");
                    return;
                }
                setGold_coins(getGold_coins() - buying_equipment.getPrice());
                removeEquipment(gc, type_name);
                System.out.println("\u001B[31m" +gc.getEquipment(type_name).getName()+ " is removed from "+gc.getName() + "\u001B[0m" + "\n");
                gc.setEquipment(buying_equipment, type_name);
                putEquipment(gc, buying_equipment);
                System.out.println("\u001B[32m" +buying_equipment.getName()+ " is added to "+gc.getName()+ " ("+character+")" +"\u001B[0m" + "\n");
            } else {
                System.out.println("\u001B[31m" + "You haven't enogh gold coins to buy this equipment" + "\u001B[0m" + "\n");
            }
        }
    }

    public void buyCharacter(GameCharacter buying_character, String type_name) {
        ConfirmMenu cm = new ConfirmMenu();
        if (cm.getResponse()) {
            if (getArmy().getCharacter(type_name) == null) {
                if (getGold_coins() >= buying_character.getPrice() && shouldUserBuy(buying_character, getGold_coins(), type_name)) {
                    setGold_coins(getGold_coins() - buying_character.getPrice());
                    getArmy().setCharacter(buying_character, type_name);
                    System.out.println("\u001B[32m" +buying_character.getName()+ " ("+type_name+") is added to your Army." + "\u001B[0m" + "\n");
                } else if (getGold_coins() < buying_character.getPrice()) {
                    System.out.println("\u001B[31m" + "You haven't enogh gold coins to buy this character" + "\u001B[0m" + "\n");
                } else {
                    System.out.println("\u001B[31m" + "You will not be able to complete your army after buying this one. So try another." + "\u001B[0m" + "\n");
                }
            } else {
                if(checkForExistingCharacters(buying_character)){
                    System.out.println("\u001B[31m" + "You already have this character. So try another." + "\u001B[0m" + "\n");
                    return;
                }
                int price_if_sold = (int) (getGold_coins() + Math.round((getArmy().getCharacter(type_name).getPrice()) * 0.9));
                if (price_if_sold >= buying_character.getPrice() && shouldUserBuy(buying_character, price_if_sold, type_name) ) {
                    setGold_coins(price_if_sold - buying_character.getPrice());
                    getArmy().setCharacter(buying_character, type_name);
                    System.out.println("\u001B[32m" +buying_character.getName()+ " ("+type_name+") is added to your Army." + "\u001B[0m" + "\n");
                } else if (getGold_coins() + price_if_sold < buying_character.getPrice()) {
                    System.out.println("\u001B[31m" + "You haven't enogh gold coins to buy this character" + "\u001B[0m" + "\n");
                } else {
                    System.out.println("\u001B[31m" + "You will not be able to buy this charcter after selling existing one. So try another." + "\u001B[0m" + "\n");
                }
            }
        }
    }
}
