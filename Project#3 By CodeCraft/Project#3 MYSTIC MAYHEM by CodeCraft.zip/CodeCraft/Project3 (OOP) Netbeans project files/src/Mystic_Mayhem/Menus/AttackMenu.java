package Mystic_Mayhem.Menus;

import Mystic_Mayhem.BattleFeild;
import Mystic_Mayhem.GameData;
import Mystic_Mayhem.User;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class AttackMenu extends Menu {

    private static User USER;
    private static int USER_ID;
    private List<String> user_names = new ArrayList<>();
    private List<Integer> user_ids = new ArrayList<>();

    public AttackMenu(User user, int index) {
        super("Attack");
        USER = user;
        USER_ID = index;

        createMenu();
        activateMenu();
    }

    @Override
    public void createMenu() {
        createUserDataLists();
        menu_items.add("Select Opponent");
        int count = 1;
        Iterator<String> iterator = user_names.iterator();
        while (iterator.hasNext()) {
            String name = iterator.next();
            menu_items.add(count + ".\t" + name + "\tXP : " + GameData.getUsers().get(user_ids.get(count - 1)).getXP() + "\n" + (GameData.getUsers().get(user_ids.get(count - 1)).getUserArmyDetails()));
            count++;
        }
        menu_items.add(count + ".\tBack");
    }

    private void createUserDataLists() {
        List<String> temp_names = new ArrayList<>(GameData.getUSER_NAMES());
        List<Integer> temp_index = new ArrayList<>(GameData.getUSER_IDS());
        int index;
        for (int i = 0; i < temp_names.size(); i++) {
            if (temp_names.get(i).equals(USER.getUser_name()) || !GameData.getUsers().get(temp_index.get(i)).getArmy().isCompleted()) {
                continue;
            }
            user_names.add(temp_names.get(i));
            user_ids.add(temp_index.get(i));
        }

    }

    @Override
    public int getUserInputs(int limit) {
        limit = user_names.size() + 1;
        int response = getIntegerSelection();
        while (response == -1 || (response > limit) || (response < 1)) {
            System.err.println("\u001B[31m" + "Invalid Input. Try Again.\n" + "\u001B[0m");
            System.out.println("Enter your choice :\t");
            response = getIntegerSelection();
        }
        return response;
    }

    @Override
    public void chooseMenuItem(int response) {
        if (response >= 1 && response <= user_names.size()) {
            String res = GameData.getUsers().get(user_ids.get(response - 1)).getHome_ground();
            if (res.equals(GameData.getBACK())) {
                goBack();
            } else {
                System.out.println("################\n" + "\u001B[5m" + "Battle Field : " + res + "\u001B[0m" + "\n################");
                BattleFeild battleFeild = new BattleFeild(USER, GameData.getUsers().get(user_ids.get(response - 1)), res);
            }
        } else {
            goBack();
        }
    }

    @Override
    public void goBack() {
        HomeMenu homeMenu = new HomeMenu(USER, USER_ID);
    }

    private int getResponseForSelectingHomeGround() {
        Scanner scanner = new Scanner(System.in);
        int response = -1;
        try {
            response = Integer.parseInt(scanner.nextLine());
        } catch (Exception e) {
            System.err.println("\u001B[31m" + "Invalid Input. Try Again.\n" + "\u001B[0m");
        }
        return response;
    }

    private String getHomeGroundForBattle(int final_count) {
        int response = getIntegerSelection();
        while (response == -1 || response > final_count || response < user_names.size() + 2) {
            System.err.println("\u001B[31m" + "Invalid Input. Try Again.\n" + "\u001B[0m");
            System.out.println("Enter your Battlefield :\t");
            response = getIntegerSelection();
        }
        if (response != menu_items.size() - 2) {
            return GameData.getHOME_GROUNDS()[response - user_names.size() - 2];
        } else {
            return GameData.getBACK();
        }
    }
}
