package Mystic_Mayhem.Menus;

import Mystic_Mayhem.GameData;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public abstract class Menu {

    private String topic;
    List<String> menu_items = new ArrayList<>();
    final Scanner scanner = new Scanner(System.in);

    public Menu(String topic) {
        this.topic = topic;
    }

    public int getIntegerSelection() {
        Scanner scanner = new Scanner(System.in);
        int response = -1;
        try {
            response = Integer.parseInt(scanner.nextLine());
        } catch (Exception e) {
            System.err.println("\u001B[31m" + "Invalid Input. Try Again." + "\u001B[0m" + "\n");
            System.out.println("Enter your choice :\t");
        }
        return response;
    }

    public void printMenu() {
        String menu = GameData.getFRAME()
                + "\t\t" + "\u001B[32m" + topic + "\u001B[0m"
                +  GameData.getFRAME();
        for (String item : menu_items) {
            menu += item + "\n";
        }
        menu += "\u001B[0m";
        menu += "\u001B[33m" + "\nEnter your choice :\t" + "\u001B[0m";
        System.out.println(menu);
    }

    public int getUserInputs(int limit) {
        int response = getIntegerSelection();
        while (response == -1 || (response > limit) || (response < 1)) {
            System.err.println("\u001B[31m" + "Invalid Input. Try Again." + "\u001B[0m" + "\n");
            System.out.println("Enter your choice :\t");
            response = getIntegerSelection();
        }
        return response;
    }

    public void activateMenu() {
        printMenu();
        chooseMenuItem(getUserInputs(menu_items.size()));
    }

    public void chooseMenuItem(int response) {

    }

    public void goBack() {

    }

    public void createMenu() {

    }

}
