package Mystic_Mayhem.Menus;

import Mystic_Mayhem.User;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class HomeMenu extends Menu {

    private static User USER;
    private static int USER_INDEX;

    public HomeMenu(User user, int index) {
        super("Home");
        USER = user;
        USER_INDEX = index;

        createMenu();
        activateMenu();
    }

    @Override
    public void createMenu() {
        if (USER.getArmy().isCompleted()) {
            menu_items.add("1.\tAttack");
        } else {
            menu_items.add("1.\t" + "\u001B[31m" + "Attack(You can't acces this option until having a full army)" + "\u001B[0m");
        }
        menu_items.add("2.\tShop");
        menu_items.add("3.\tView Profile");
        menu_items.add("4.\tChange Name");
        menu_items.add("5.\tInfo");
        menu_items.add("6.\tLog out");
    }

    @Override
    public int getUserInputs(int limit) {
        int response = getIntegerSelection();
        if (USER.getArmy().isCompleted()) {
            while (response == -1 || response > limit || response < 1) {
                System.err.println("\u001B[31m" + "Invalid Input. Try Again." + "\u001B[0m" + "\n");
                System.out.println("Enter your choice :\t");
                response = getIntegerSelection();
            }
        } else {
            while (response == -1 || response > limit || response < 2) {
                System.err.println("\u001B[31m" + "Invalid Input. Try Again." + "\u001B[0m" + "\n");
                System.out.println("Enter your choice :\t");
                response = getIntegerSelection();
            }
        }
        return response;
    }

    @Override
    public void chooseMenuItem(int response) {
        switch (response) {
            case 1:
                goToAttackMenu();
                break;
            case 2:
                goToShopMenu();
                break;
            case 3:
                viewProfile();
                break;
            case 4:
                changeName();
                break;
            case 5:
                showInfo();
                break;
            case 6:
                goBack();
                break;
            default:
                break;
        }
    }

    @Override
    public void goBack() {
        StartMenu startMenu = new StartMenu();
    }

    private void changeName() {
        USER.changeName();
        HomeMenu homeMenu = new HomeMenu(USER, USER_INDEX);
    }

    private void viewProfile() {
        USER.printProfile();
        HomeMenu homeMenu = new HomeMenu(USER, USER_INDEX);
    }

    private void goToAttackMenu() {
        AttackMenu attackMenu = new AttackMenu(USER, USER_INDEX);
    }

    private void goToShopMenu() {
        ShopMenu attackMenu = new ShopMenu(USER, USER_INDEX);
    }

    private void showInfo() {
        try {
            FileReader fileReader = new FileReader("Info.txt");
            BufferedReader reader = new BufferedReader(fileReader);
            String line = null;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
            reader.close();
            fileReader.close();
        } catch (IOException ex) {
            System.err.println("\u001B[31m" + "Info.txt file doesn't exist" + "\u001B[0m" + "\n");
        }
        HomeMenu homeMenu = new HomeMenu(USER, USER_INDEX);
    }

}
