package Mystic_Mayhem.Menus;

import Mystic_Mayhem.GameData;
import java.util.Scanner;

public class HomeGroundMenu extends Menu {

    private static String res;

    public HomeGroundMenu() {
        super("Home Grounds");

        createMenu();
        activateMenu();
    }

    @Override
    public void createMenu() {
        int count = 1;
        for (String name : GameData.getHOME_GROUNDS()) {
            menu_items.add(count + ".\t" + name);
            count++;
        }
        menu_items.add(count + ".\tBack");
    }

    @Override
    public void chooseMenuItem(int response) {
        if (response == menu_items.size()) {
            goBack();
        } else {
            res = GameData.getHOME_GROUNDS()[response - 1];
        }
    }

    public String getRes() {
        return res;
    }

    @Override
    public void goBack() {

    }
}
