package Mystic_Mayhem.Menus;

import Mystic_Mayhem.GameData;
import Mystic_Mayhem.User;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class ChoosePlayerMenu extends Menu {

    private List<String> users;
    private List<Integer> ids = new ArrayList<>();
    private Set<Integer> keys;

    public ChoosePlayerMenu() {
        super("Choose Player Menu");

        createMenu();
        activateMenu();
    }

    @Override
    public void createMenu() {
        menu_items.add("1.\tNew Player");
        users = GameData.getUSER_NAMES();
        for (int i = 1; i <= users.size(); i++) {
            ids.add(i);
        }
        int i = 2;
        for (String key : users) {
            if (key.equals(GameData.getDEFAULT_PLAYER())) {
                ids.remove(i - 2);
                continue;
            }

            menu_items.add(String.valueOf(i) + ".\t" + key);
            i++;
        }
        menu_items.add(i + ".\tBack");
    }

    @Override
    public void chooseMenuItem(int response) {
        if (response == menu_items.size()) {
            goBack();
        }
        switch (response) {
            case 1:
                createNewUser();
                break;
            default:
                User current_user = GameData.getUsers().get(ids.get(response - 2));
                goToHomeMenu(current_user, current_user.getUser_ID());
                break;
        }
    }

    private void createNewUser() {
        System.out.println("Enter your name :\t");
        String name = scanner.nextLine();
        System.out.println("Enter your user name :\t");
        String user_name = scanner.nextLine();
        while (GameData.getUSER_NAMES().contains(user_name)) {
            System.out.println("\u001B[31m" + "This name is already used." + "\u001B[0m" + "\nEnter your user name :\t\n");
            user_name = scanner.nextLine();
        }

        HomeGroundMenu homeGroundMenu = new HomeGroundMenu();
        User new_user = new User(name, user_name, homeGroundMenu.getRes());
        GameData.addUsers(new_user);
        goToHomeMenu(new_user, new_user.getUser_ID());
    }

    private void goToHomeMenu(User user, int index) {
        HomeMenu homeMenu = new HomeMenu(user, index);
    }

    @Override
    public void goBack() {
        StartMenu startMenu = new StartMenu();
    }

}
