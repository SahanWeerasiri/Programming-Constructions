package Mystic_Mayhem.Menus;

public class ConfirmMenu extends Menu {

    private boolean res;

    public ConfirmMenu() {
        super("Are you Sure ?");

        createMenu();
        activateMenu();
    }

    @Override
    public void createMenu() {
        menu_items.add("1.\tYes");
        menu_items.add("2.\tNo");
    }

    @Override
    public void chooseMenuItem(int response) {
        switch (response) {
            case 1: res = true;break;
            case 2: res = false;break;
            default: break;
        }
    }

    public boolean getResponse() {
        return res;
    }

    @Override
    public void goBack() {
    }

}
