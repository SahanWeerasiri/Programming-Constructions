package Mystic_Mayhem.Menus;

import Mystic_Mayhem.GameData;

public class StartMenu extends Menu {

    public StartMenu() {
        super("Start Menu");

        createMenu();
        activateMenu();
    }

    @Override
    public void createMenu() {
        menu_items.add("1.\tLog in");
        menu_items.add("2.\tExit");
    }

    @Override
    public void chooseMenuItem(int response) {
        switch (response) {
            case 1:
                logIn();
                break;
            case 2:
                exit();
                break;
            default:
                break;
        }
    }

    private void logIn() {
        ChoosePlayerMenu startMenu = new ChoosePlayerMenu();
    }

    private void exit() {
        System.out.println("\u001B[34m" + "Good Bye!" + "\u001B[0m");
        GameData.saveGameData();
        System.exit(0);
    }

    @Override
    public void goBack() {
    }

}
