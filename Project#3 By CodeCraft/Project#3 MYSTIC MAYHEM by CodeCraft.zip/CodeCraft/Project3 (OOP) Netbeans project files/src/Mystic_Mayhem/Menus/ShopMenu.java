package Mystic_Mayhem.Menus;

import Mystic_Mayhem.GameData;
import Mystic_Mayhem.User;
import java.util.Scanner;

public class ShopMenu extends Menu {

    private static User USER;
    private static int USER_ID;

    public ShopMenu(User user, int index) {
        super("Shop");
        USER = user;
        USER_ID = index;

        createMenu();
        activateMenu();
    }

    @Override
    public void createMenu() {
        menu_items.add("1.\tBuy Army");
        if (USER.getArmy().isCompleted()) {
            menu_items.add("2.\tBuy Equipments");
        } else {
            menu_items.add("2.\t"+"\u001B[31m" +"Buy Eqipments(You can't acces this option until having a full army)"+"\u001B[0m");
        }
        menu_items.add("3.\tBack");
    }

    @Override
    public void chooseMenuItem(int response) {
        switch (response) {
            case 1:
                goToBuyMenu(GameData.getARMY());
                break;
            case 2:
                goToBuyMenu(GameData.getEQUIPMENT());
                break;
            case 3:
                goBack();
                break;
            default:
                break;
        }
    }

    @Override
    public int getUserInputs(int limit) {
        int response = getIntegerSelection();
        while (response == -1 || (response > limit) || (response < 1) || (!USER.getArmy().isCompleted() && response == 2)) {
            System.err.println("\u001B[31m" + "Invalid Input. Try Again." + "\u001B[0m" + "\n");
            System.out.println("Enter your choice :\t");
            response = getIntegerSelection();
        }
        return response;
    }

    @Override
    public void goBack() {
        HomeMenu homeMenu = new HomeMenu(USER, USER_ID);
    }

    private void goToBuyMenu(String type) {
        BuyMenu buyMenu = new BuyMenu(USER, USER_ID, type);
    }

}
