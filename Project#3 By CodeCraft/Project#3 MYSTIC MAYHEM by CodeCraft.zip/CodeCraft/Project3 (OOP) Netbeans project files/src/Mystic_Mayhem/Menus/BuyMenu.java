package Mystic_Mayhem.Menus;

import Mystic_Mayhem.Characters.Archer;
import Mystic_Mayhem.Characters.GameCharacter;
import Mystic_Mayhem.Characters.Healer;
import Mystic_Mayhem.Characters.Knight;
import Mystic_Mayhem.Characters.Mage;
import Mystic_Mayhem.Characters.MythicalCreature;
import Mystic_Mayhem.Equipments.Armour;
import Mystic_Mayhem.Equipments.Artefact;
import Mystic_Mayhem.Equipments.Equipment;
import Mystic_Mayhem.GameData;
import Mystic_Mayhem.User;
import java.util.HashMap;

public class BuyMenu extends Menu {

    private static User USER;
    private static int USER_ID;
    private final String type;

    public BuyMenu(User user, int index, String type) {
        super("Buy");
        USER = user;
        USER_ID = index;
        this.type = type;

        createMenu();
        activateMenu();
    }

    @Override
    public void createMenu() {
        int count = 1;
        if (type.equals(GameData.getARMY())) {//Army
            String[][] names = GameData.getALL_CHARACTER_NAMES();
            for (String[] category : names) {
                menu_items.add("########################");
                menu_items.add("\u001B[32m" + category[0] + "\u001B[0m");

                for (int i = 1; i < category.length; i++) {
                    GameCharacter gc = (GameCharacter) GameData.getCHARACTERS().get(category[0]).get(category[i]);
                    menu_items.add(count + ".\t" + String.format("%12s", gc.getName()) + "\tSpeed: " + gc.getSpeed() + "\tPrice: " + gc.getPrice() + " gc\tAttack: " + gc.getAttack() + "\tDefense: " + gc.getDefense() + "\tHealth: " + gc.getHealth() + "\tOrigin: " + gc.getCategory());
                    count++;
                }
            }
        } else {//Equipments
            String[][] names = GameData.getALL_EQUIPMENT_NAMES();
            for (String[] category : names) {
                menu_items.add("########################");
                menu_items.add("\u001B[32m" + category[0] + "\u001B[0m");
                for (int i = 1; i < category.length; i++) {
                    Equipment equip = (Equipment) GameData.getEQUIPMENTS().get(category[0]).get(category[i]);
                    menu_items.add(count + ".\t" + String.format("%12s", equip.getName()) + "\tSpeed: " + equip.getSpeed() + "\tPrice: " + equip.getPrice() + " gc\tAttack: " + equip.getAttack() + "\tDefense: " + equip.getDefense() + "\tHealth: " + equip.getHealth());
                    count++;
                }
            }//Game Charcters for put equipments
            menu_items.add("\n\n" + count + ".\tBack");
            count++;
            menu_items.add("\nSelect the Character after selecting the equipment");
            menu_items.add(count + ".\tArcher");
            count++;
            menu_items.add(count + ".\tKnight");
            count++;
            menu_items.add(count + ".\tMage");
            count++;
            menu_items.add(count + ".\tHealer");
            count++;
            menu_items.add(count + ".\tMythical Creature");
            count++;

        }
        menu_items.add("\n\n" + count + ".\tBack\n");
        if (type.equals(GameData.getARMY())) {
            menu_items.add("+---------------------------------------+\n"
                    + "\t" + "\u001B[5m" + "Gold Coins :" + "\u001B[0m" + "\t" + "\u001B[32m" + USER.getGold_coins() + "\u001B[0m" + "\n"
                    + "+---------------------------------------+\n");
        } else {
            menu_items.add("+---------------------------------------+\n"
                    + "\t" + "\u001B[5m" + "Gold Coins :" + "\u001B[0m" + "\t" + "\u001B[32m" + USER.getGold_coins() + "\u001B[0m" + "\n"
                    + "+---------------------------------------+\n" + "\n## Use first menu for your first choice and the second one for second choice\n");
        }
    }

    @Override
    public void chooseMenuItem(int response) {
        /*
        1-5     Archer
        6-10    Knight
        11-15   Mage
        16-20   Healer
        21-25   MythicalCreature
        26 Back
        
        1-3   Armour
        4-6   Artefact
        7-back
        8-12 Characters
        13-back
         */
        if (type.equals(GameData.getARMY())) {
            GameCharacter buying_character;
            HashMap<String, HashMap<String, GameCharacter>> copy = (HashMap<String, HashMap<String, GameCharacter>>) GameData.getCHARACTERS().clone();
            if (response >= 1 && response <= 5) {
                GameCharacter gc = copy.get(GameData.getARCHER()).get(GameData.getARCHER_NAMES()[response - 1]);
                buying_character = new Archer(gc.getName(), gc.getSpeed(), gc.getPrice(), gc.getAttack(), gc.getDefense(), gc.getHealth(), gc.getCategory());
                USER.buyCharacter(buying_character, GameData.getARCHER());
                BuyMenu buyMenu = new BuyMenu(USER, USER_ID, type);
            } else if (response >= 6 && response <= 10) {
                GameCharacter gc = copy.get(GameData.getKNIGHT()).get(GameData.getKNIGHT_NAMES()[response - 6]);
                buying_character = new Knight(gc.getName(), gc.getSpeed(), gc.getPrice(), gc.getAttack(), gc.getDefense(), gc.getHealth(), gc.getCategory());
                USER.buyCharacter(buying_character, GameData.getKNIGHT());
                BuyMenu buyMenu = new BuyMenu(USER, USER_ID, type);
            } else if (response >= 11 && response <= 15) {
                GameCharacter gc = copy.get(GameData.getMAGE()).get(GameData.getMAGE_NAMES()[response - 11]);
                buying_character = new Mage(gc.getName(), gc.getSpeed(), gc.getPrice(), gc.getAttack(), gc.getDefense(), gc.getHealth(), gc.getCategory());
                USER.buyCharacter(buying_character, GameData.getMAGE());
                BuyMenu buyMenu = new BuyMenu(USER, USER_ID, type);
            } else if (response >= 16 && response <= 20) {
                GameCharacter gc = copy.get(GameData.getHEALER()).get(GameData.getHEALER_NAMES()[response - 16]);
                buying_character = new Healer(gc.getName(), gc.getSpeed(), gc.getPrice(), gc.getAttack(), gc.getDefense(), gc.getHealth(), gc.getCategory());
                USER.buyCharacter(buying_character, GameData.getHEALER());
                BuyMenu buyMenu = new BuyMenu(USER, USER_ID, type);
            } else if (response >= 21 && response <= 25) {
                GameCharacter gc = copy.get(GameData.getMYTHICAL_CREATURE()).get(GameData.getMYTHICAL_CREATURE_NAMES()[response - 21]);
                buying_character = new MythicalCreature(gc.getName(), gc.getSpeed(), gc.getPrice(), gc.getAttack(), gc.getDefense(), gc.getHealth(), gc.getCategory());
                USER.buyCharacter(buying_character, GameData.getMYTHICAL_CREATURE());
                BuyMenu buyMenu = new BuyMenu(USER, USER_ID, type);
            } else {
                goBack();
            }
        } else {
            Equipment buying_equipment;
            HashMap<String, HashMap<String, Equipment>> copy = (HashMap<String, HashMap<String, Equipment>>) GameData.getEQUIPMENTS().clone();
            if (response >= 1 && response <= 3) {
                System.out.println("Enter your character :\t");
                buying_equipment = (Armour) copy.get(GameData.getARMOUR()).get(GameData.getARMOUR_NAMES()[response - 1]);
                String res = getCharacterForEquipments(12);
                if (res.equals(GameData.getBACK())) {
                    goBack();
                } else {
                    USER.buyEquipment(buying_equipment, res, GameData.getARMOUR());
                }
                BuyMenu buyMenu = new BuyMenu(USER, USER_ID, type);
            } else if (response >= 4 && response <= 6) {
                System.out.println("Enter your character :\t");
                buying_equipment = (Artefact) copy.get(GameData.getARTEFACT()).get(GameData.getARTEFACT_NAMES()[response - 4]);
                String res = getCharacterForEquipments(13);
                if (res.equals(GameData.getBACK())) {
                    goBack();
                } else {
                    USER.buyEquipment(buying_equipment, res, GameData.getARTEFACT());
                }
                BuyMenu buyMenu = new BuyMenu(USER, USER_ID, type);
            } else {
                goBack();
            }
        }
    }

    @Override
    public int getUserInputs(int limit) {
        if (type.equals(GameData.getARMY())) {
            limit = 26;
        } else {
            limit = 7;
        }
        int response = getIntegerSelection();
        while (response == -1 || (response > limit) || (response < 1)) {
            System.err.println("\u001B[31m" + "Invalid Input. Try Again." + "\u001B[0m" + "\n");
            System.out.println("Enter your choice :\t");
            response = getIntegerSelection();
        }
        return response;
    }

    @Override
    public void goBack() {
        ShopMenu shopMenu = new ShopMenu(USER, USER_ID);
    }

    private int getResponseForSelectingCharacter() {
        int response = -1;
        try {
            response = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.err.println("\u001B[31m" + "Invalid Input. Try Again." + "\u001B[0m" + "\n");
        }
        return response;
    }

    private String getCharacterForEquipments(int final_count) {
        int response = getIntegerSelection();
        while (response == -1 || response > final_count || response < 8) {
            System.err.println("\u001B[31m" + "Invalid Input. Try Again." + "\u001B[0m" + "\n");
            System.out.println("Enter your Character :\t");
            response = getIntegerSelection();
        }
        switch (response) {
            case 8:
                return GameData.getARCHER();
            case 9:
                return GameData.getKNIGHT();
            case 10:
                return GameData.getMAGE();
            case 11:
                return GameData.getHEALER();
            case 12:
                return GameData.getMYTHICAL_CREATURE();
            case 13:
                return GameData.getBACK();
            default:
                return "";
        }

    }

}
