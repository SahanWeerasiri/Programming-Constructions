package Mystic_Mayhem;

import Mystic_Mayhem.Menus.HomeMenu;

public class BattleFeild {

    private final User USER;
    private final User OPPONENT;
    private Player attacker;
    private Player defender;
    private final int TURNS = 10;
    boolean is_finished = false;

    public BattleFeild(User attaker, User defender, String location) {
        USER = attaker;
        OPPONENT = defender;
        this.attacker = new Player(attaker, location);
        this.defender = new Player(defender, location);
        startBattle();
    }

    private void swap() {
        Player temp = attacker;
        attacker = defender;
        defender = temp;
    }

    private void startBattle() {
        System.out.println("\u001B[31m" + attacker.getUser().getUser_name() + " Vs. " + defender.getUser().getUser_name() + "\u001B[0m" + "\n");

        while ((attacker.getTurn() <= TURNS || defender.getTurn() <= TURNS) && !is_finished) {

            System.out.println("\u001B[34m" + "Turn " + attacker.getTurn() + "\u001B[0m" + ": " + attacker.getUser().getUser_name());
            

            //Normal Turn
            attacker.attack(false);
            defender.attackedByOther(attacker, false);
            attacker.setTurn(attacker.getTurn() + 1);

            //Check for ending battle
            if (defender.getCuurent_defender() == null) {
                is_finished = true;
                endBattle();
                break;
            }

            //bonus health
            float health = attacker.getBonusHealth();
            if (health != 0) {
                attacker.getCuurent_attacker(false).setHealth(attacker.getCuurent_attacker(false).getHealth() + health);
            }

            //bonus attack
            float bonus = attacker.getBonusAttack();
            if (bonus != 0) {
                attacker.attack(true);
                defender.attackedByOther(attacker, true);

            }

            //check for ending battle
            if (defender.getCuurent_defender() == null) {
                is_finished = true;
                endBattle();
                break;
            }

            attacker.getCuurent_attacker(true);
            //switch turn
            swap();
        }
        endBattle();
    }

    private void endBattle() {
        if (!is_finished) {//Draw
            System.out.println("\u001B[32m" + "draw!" + "\u001B[0m");

            attacker.restore();
            defender.restore();
        } else {//Finished            
            changeResults(attacker, defender);

            String msg = "\u001B[32m" + attacker.getUser().getUser_name() + " won!" + "\u001B[0m" + "\n";
            msg += USER.getUser_name() + " XP: " + USER.getXP() + " gold coins: " + USER.getGold_coins() + "\n";
            msg += OPPONENT.getUser_name() + " XP: " + OPPONENT.getXP() + " gold coins: " + OPPONENT.getGold_coins() + "\n";
            System.out.println(msg);

            attacker.restore();
            defender.restore();
        }
        HomeMenu homeMenu = new HomeMenu(USER, USER.getUser_ID());
    }

    private void changeResults(Player winner, Player looser) {
        winner.getUser().setGold_coins((int) (winner.getUser().getGold_coins() + looser.getUser().getGold_coins() * 0.1));
        winner.getUser().setXP(winner.getUser().getXP() + 1);
        looser.getUser().setGold_coins((int) (looser.getUser().getGold_coins() - looser.getUser().getGold_coins() * 0.1));
    }
}
