package Mystic_Mayhem;

import Mystic_Mayhem.Characters.MythicalCreature;
import Mystic_Mayhem.Characters.Archer;
import Mystic_Mayhem.Characters.GameCharacter;
import Mystic_Mayhem.Characters.Knight;
import Mystic_Mayhem.Characters.Mage;
import Mystic_Mayhem.Characters.Healer;
import java.io.Serializable;

public class Army implements Serializable {

    private Archer archer = null;
    private Knight knight = null;
    private Mage mage = null;
    private Healer healer = null;
    private MythicalCreature mythicalCreature = null;

    public boolean isCompleted() {
        return (archer != null && knight != null && mage != null && healer != null && mythicalCreature != null);
    }

    public GameCharacter getCharacter(String type_name) {
        if (type_name.equals(GameData.getARCHER())) {
            return archer;
        } else if (type_name.equals(GameData.getKNIGHT())) {
            return knight;
        } else if (type_name.equals(GameData.getMAGE())) {
            return mage;
        } else if (type_name.equals(GameData.getHEALER())) {
            return healer;
        } else if(type_name.equals(GameData.getMYTHICAL_CREATURE())){
            return mythicalCreature;
        }else
            return  null;
    }

    public void setCharacter(GameCharacter gc, String type_name) {
        if (type_name.equals(GameData.getARCHER())) {
            archer = (Archer) gc;
        } else if (type_name.equals(GameData.getKNIGHT())) {
            knight = (Knight) gc;
        } else if (type_name.equals(GameData.getMAGE())) {
            mage = (Mage) gc;
        } else if (type_name.equals(GameData.getHEALER())) {
            healer = (Healer) gc;
        } else {
            mythicalCreature = (MythicalCreature) gc;
        }

    }

    public GameCharacter getCharacterByName(String name) {
        if (name.equals(getArcher().getName())) {
            return getArcher();
        } else if (name.equals(getKnight().getName())) {
            return getKnight();
        } else if (name.equals(getMage().getName())) {
            return getMage();
        } else if (name.equals(getHealer().getName())) {
            return getHealer();
        } else {
            return getMythicalCreature();
        }
    }

    public Archer getArcher() {
        return archer;
    }

    public void setArcher(Archer archer) {
        this.archer = archer;
    }

    public Knight getKnight() {
        return knight;
    }

    public void setKnight(Knight knight) {
        this.knight = knight;
    }

    public Mage getMage() {
        return mage;
    }

    public void setMage(Mage mage) {
        this.mage = mage;
    }

    public Healer getHealer() {
        return healer;
    }

    public void setHealer(Healer healer) {
        this.healer = healer;
    }

    public MythicalCreature getMythicalCreature() {
        return mythicalCreature;
    }

    public void setMythicalCreature(MythicalCreature mythicalCreature) {
        this.mythicalCreature = mythicalCreature;
    }

}
