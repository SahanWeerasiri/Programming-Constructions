package Mystic_Mayhem.Characters;

public class Healer extends GameCharacter{

    public Healer(String name,float speed,int price,float attack,float defense,float health,String category){
        super(name,speed, price, attack, defense, health,null,null,category);
    }
    @Override
    public boolean isAHealer(){
        return true;
    }
}
