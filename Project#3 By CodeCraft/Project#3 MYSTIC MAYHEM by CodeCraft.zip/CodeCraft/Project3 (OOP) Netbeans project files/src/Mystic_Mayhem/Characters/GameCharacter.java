package Mystic_Mayhem.Characters;

import HomeGrounds.IHomeGround;
import Mystic_Mayhem.Equipments.Armour;
import Mystic_Mayhem.Equipments.Artefact;
import Mystic_Mayhem.Equipments.Equipment;
import Mystic_Mayhem.GameData;
import java.io.Serializable;
import java.text.DecimalFormat;

public abstract class GameCharacter implements IHomeGround, Serializable {

    private float speed, attack, defense, health;
    private int price;
    private String name;
    private Armour armour;
    private Artefact artefact;
    private final String category;
    
    public GameCharacter(String name, float speed, int price, float attack, float defense, float health, Armour armour, Artefact artefact, String category) {
        this.attack = attack;
        this.defense = defense;
        this.armour = armour;
        this.artefact = artefact;
        this.health = health;
        this.name = name;
        this.price = price;
        this.speed = speed;
        this.category = category;
    }

    public GameCharacter getInstance() {
        return this;
    }

    public String getCategory() {
        return category;
    }

    public float getSpeed() {
        return speed;
    }

    public void setSpeed(float speed) {
        this.speed = speed;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public float getAttack() {
        return attack;
    }

    public void setAttack(float attack) {
        this.attack = attack;
    }

    public float getDefense() {
        return defense;
    }

    public void setDefense(float defense) {
        this.defense = defense;
    }

    public float getHealth() {
        return health;
    }
    
    public void setHealth(float health) {
        DecimalFormat df = new DecimalFormat("0.0");
        if (health < 0) {
            this.health = 0;
        } else {
            this.health = Float.parseFloat(df.format(health));
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Armour getArmour() {
        return armour;
    }

    public void setArmour(Armour armour) {
        this.armour = armour;
    }

    public Artefact getArtefact() {
        return artefact;
    }

    public void setArtefact(Artefact artefact) {
        this.artefact = artefact;
    }

    public Equipment getEquipment(String type_name) {
        if (type_name.equals(GameData.getARMOUR())) {
            return armour;
        } else {
            return artefact;
        }
    }

    public void setEquipment(Equipment equipment, String type_name) {
        if (type_name.equals(GameData.getARMOUR())) {
            armour = (Armour) equipment;
        } else {
            artefact = (Artefact) equipment;
        }
    }

    @Override
    public void changeCharacterProperties(String home_ground) {
        if (home_ground.equals(GameData.getHOME_GROUNDS()[0])) {//Hillcrest
            if (getCategory().equals(GameData.getHIGHLANDERS())) {
                setDefense(getDefense() + 1);
                setAttack(getAttack()+ 1);
            } else if (getCategory().equals(GameData.getMARSHALANDERS())) {
                setSpeed(getSpeed() - 1);
            } else if (getCategory().equals(GameData.getSUNCHILDREN())) {
                setSpeed(getSpeed() - 1);
            } else {

            }
        } else if (home_ground.equals(GameData.getHOME_GROUNDS()[1])) {//Marshaland
            if (getCategory().equals(GameData.getHIGHLANDERS())) {

            } else if (getCategory().equals(GameData.getMARSHALANDERS())) {
                setDefense(getDefense() + 2);
            } else if (getCategory().equals(GameData.getSUNCHILDREN())) {
                setAttack(getAttack() - 1);
            } else {
                setSpeed(getSpeed() - 1);
            }
        } else if (home_ground.equals(GameData.getHOME_GROUNDS()[2])) {//Desert
            if (getCategory().equals(GameData.getHIGHLANDERS())) {

            } else if (getCategory().equals(GameData.getMARSHALANDERS())) {
                setHealth(getHealth() - 1);
            } else if (getCategory().equals(GameData.getSUNCHILDREN())) {
                setAttack(getAttack() + 1);
            } else {

            }
        } else {//Arcane
            if (getCategory().equals(GameData.getHIGHLANDERS())) {
                setSpeed(getSpeed() - 1);
                setDefense(getDefense() - 1);
            } else if (getCategory().equals(GameData.getMARSHALANDERS())) {
                setSpeed(getSpeed() - 1);
                setDefense(getDefense() - 1);
            } else if (getCategory().equals(GameData.getSUNCHILDREN())) {

            } else {
                setAttack(getAttack() + 2);
            }
        }
    }

    @Override
    public float getBonusTurnIncrement(String home_ground) {
        if (home_ground.equals(GameData.getHOME_GROUNDS()[0]) && getCategory().equals(GameData.getHIGHLANDERS())) {
            return (float) (0.2 * getAttack());
        }
        return 0;
    }

    @Override
    public float getIncrementOHealth(String home_ground) {
        if (home_ground.equals(GameData.getHOME_GROUNDS()[3]) && getCategory().equals(GameData.getMYSTICS())) {
            return (float) (0.1 * getHealth());
        }
        return 0;
    }

    public boolean isAHealer() {
        return false;
    }

}
