package Mystic_Mayhem.Characters;

public class Mage extends GameCharacter {

    public Mage(String name, float speed, int price, float attack, float defense, float health, String category) {
        super(name, speed, price, attack, defense, health, null, null, category);
    }

}
