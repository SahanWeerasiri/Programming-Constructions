package Mystic_Mayhem.Characters;

public class Knight extends GameCharacter{

    public Knight(String name,float speed,int price,float attack,float defense,float health,String category){
        super(name,speed, price, attack, defense, health,null,null,category);
    }
    
    
}
