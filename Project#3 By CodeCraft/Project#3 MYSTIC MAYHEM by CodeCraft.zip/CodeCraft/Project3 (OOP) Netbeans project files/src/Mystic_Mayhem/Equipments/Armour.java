package Mystic_Mayhem.Equipments;

public class Armour extends Equipment {

    public Armour(String name, float speed, int price, float attack, float defense, float health) {
        super(speed, price, attack, defense, health, name);
    }

}
