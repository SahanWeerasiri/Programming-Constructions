package Mystic_Mayhem.Equipments;

import java.io.Serializable;

public abstract class Equipment implements Serializable {

    private final float speed;
    private final float attack;
    private final float defense;
    private final float health;
    private final int price;
    private final String name;

    public Equipment(float speed, int price, float attack, float defense, float health, String name) {
        this.speed = speed;
        this.price = price;
        this.attack = attack;
        this.defense = defense;
        this.health = health;
        this.name = name;
    }

    public float getSpeed() {
        return speed;
    }

    public int getPrice() {
        return price;
    }

    public float getAttack() {
        return attack;
    }

    public float getDefense() {
        return defense;
    }

    public float getHealth() {
        return health;
    }

    public String getName() {
        return name;
    }
}
