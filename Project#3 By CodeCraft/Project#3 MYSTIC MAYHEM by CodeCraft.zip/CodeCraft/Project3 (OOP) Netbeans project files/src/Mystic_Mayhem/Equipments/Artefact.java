package Mystic_Mayhem.Equipments;

public class Artefact extends Equipment {

    public Artefact(String name, float speed, int price, float attack, float defense, float health) {
        super(speed, price, attack, defense, health, name);
    }

}
