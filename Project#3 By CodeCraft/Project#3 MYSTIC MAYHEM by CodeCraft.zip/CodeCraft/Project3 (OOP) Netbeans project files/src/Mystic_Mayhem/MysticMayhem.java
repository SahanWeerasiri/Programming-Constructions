package Mystic_Mayhem;

import Mystic_Mayhem.Menus.StartMenu;

public class MysticMayhem {

    public static void main(String args[]) {
        System.out.println(GameData.getGAME_NAME());
        GameData.loadGameData();
        GameData.createCharactersAndEquipments();

        //For creating default users in case of data erasing
        if(GameData.getUsers().isEmpty()){
            GameData.createDefaultUser();
        }
                        
        StartMenu startMenu = new StartMenu();
    }

}
