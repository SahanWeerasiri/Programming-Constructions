package HomeGrounds;

public interface IHomeGround {

    public void changeCharacterProperties(String home_ground);

    public float getBonusTurnIncrement(String home_ground);

    public float getIncrementOHealth(String home_ground);
}
